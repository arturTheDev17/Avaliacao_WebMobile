# observer-pattern-example
Observer Pattern example in Java - Desgin patterns tutorial by Java9s.com

Watch the complete explanation on Youtube:

Observer pattern: https://www.youtube.com/watch?v=SrxeQ1spoJg

All my videos: https://www.youtube.com/user/java9s/videos



