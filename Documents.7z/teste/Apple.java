package com.java9s.tutorials.designpattern.observer;
/**
 * Design Pattern series by http://java9s.com
 * @author java9s.com
 *
 */
public class Apple extends Stock{
	public Apple(){
		this.setName("Apple");
	}
}
