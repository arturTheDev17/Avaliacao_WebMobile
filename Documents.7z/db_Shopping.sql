CREATE DATABASE ShoppingDB;
USE ShoppingDB;

create table Categoria (
	id_categoria int auto_increment primary key,
    nome_categoria varchar(255)
);

create table Proprietario (
id_proprietario int auto_increment primary key,
nome varchar(255),
cpf char(11)
);

create table Unidade (
id_unidade int auto_increment primary key,
numero_andar int,
metros_quadrados decimal(10,2),
valor_aluguel decimal(10,2),
id_categoria int,
id_proprietario int,
foreign key ( id_categoria ) references Categoria ( id_categoria ),
foreign key ( id_proprietario ) references Proprietario ( id_proprietario )
);

create table Fatura (
id_fatura int auto_increment primary key,
id_unidade int,
data_vencimento date,
data_pagamento date,
status_fatura varchar(20),
foreign key (id_unidade) references Unidade (id_unidade)
);

create table Horario_Funcionamento (
id_horario int auto_increment primary key,
id_unidade int,
dia_semana VARCHAR(20),
horario_abertura TIME,
horario_fechamento TIME,
foreign key (id_unidade) references Unidade ( id_unidade )
);

-- INSERT

INSERT INTO Categoria (nome_categoria) VALUES
('Roupas'),
('Alimentício'),
('Eletrônicos'),
('Calçados'),
('Acessórios');

INSERT INTO Proprietario (nome, CPF) VALUES

('João Silva', '12345678901'),
('Maria Oliveira', '98765432109'),
('Carlos Santos', '45678912304'),
('Ana Pereira', '78912345607'),
('Pedro Souza', '32165498708');

INSERT INTO Unidade (numero_andar, metros_quadrados, valor_aluguel,
id_categoria, id_proprietario) VALUES


(1, 100, 5000.00, 1, 1),
(2, 150, 7000.00, 2, 2),
(1, 80, 4000.00, 3, 3),
(3, 200, 9000.00, 4, 4),
(2, 120, 6000.00, 5, 5),
(1, 90, 4500.00, 1, 1),
(2, 160, 7500.00, 2, 2),
(1, 70, 3500.00, 3, 3),
(3, 180, 8500.00, 4, 4),
(2, 110, 5500.00, 5, 5),
(1, 95, 4700.00, 1, 1),
(2, 140, 6500.00, 2, 2),
(1, 75, 3800.00, 3, 3),
(3, 190, 8800.00, 4, 4),
(2, 130, 6200.00, 5, 5),
(1, 85, 4200.00, 1, 1),
(2, 150, 7000.00, 2, 2),
(1, 60, 3000.00, 3, 3),
(3, 170, 8000.00, 4, 4),
(2, 100, 5000.00, 5, 5);

INSERT INTO Fatura (id_unidade, data_vencimento, data_pagamento, status_fatura)
VALUES

(1, '2024-05-01', '2024-05-02', 'Pago'),
(2, '2024-05-01', NULL, 'Pendente'),
(3, '2024-05-01', '2024-05-03', 'Pago'),
(4, '2024-05-01', NULL, 'Pendente'),
(5, '2024-05-01', '2024-05-05', 'Pago'),
(6, '2024-05-01', NULL, 'Pendente'),
(7, '2024-05-01', '2024-05-04', 'Pago'),
(8, '2024-05-01', NULL, 'Pendente'),
(9, '2024-05-01', '2024-05-06', 'Pago'),
(10, '2024-05-01', NULL, 'Pendente'),
(11, '2024-05-01', '2024-05-07', 'Pago'),
(12, '2024-05-01', NULL, 'Pendente'),
(13, '2024-05-01', '2024-05-08', 'Pago'),
(14, '2024-05-01', NULL, 'Pendente'),
(15, '2024-05-01', '2024-05-09', 'Pago'),
(16, '2024-05-01', NULL, 'Pendente'),
(17, '2024-05-01', '2024-05-10', 'Pago'),
(18, '2024-05-01', NULL, 'Pendente'),
(19, '2024-05-01', '2024-05-11', 'Pago'),
(20, '2024-05-01', NULL, 'Pendente');

INSERT INTO Horario_Funcionamento (id_unidade,
dia_semana, horario_abertura, horario_fechamento) VALUES

(1, 'Segunda', '08:00:00', '20:00:00'),
(1, 'Terça', '08:00:00', '20:00:00'),
(1, 'Quarta', '08:00:00', '20:00:00'),
(1, 'Quinta', '08:00:00', '20:00:00'),
(1, 'Sexta', '08:00:00', '20:00:00'),
(1, 'Sábado', '10:00:00', '18:00:00'),
(1, 'Domingo', NULL, NULL);

-- SELECT
select * from categoria;
select * from fatura;
select * from horario_funcionamento;
select * from proprietario;
select * from unidade;

-- 1.Quais são todas as categorias de unidades existentes no shopping?
select nome_categoria FROM categoria;

-- 2.Quais são os proprietários das unidades do shopping?
select proprietario.nome from proprietario
inner join unidade on proprietario.id_proprietario like unidade.id_proprietario
group by proprietario.nome;

-- 3. Qual é o número total de unidades em cada categoria?
select categoria.nome_categoria , count(unidade.id_unidade) as 'total_unidades' from categoria
left join unidade on categoria.id_categoria like unidade.id_categoria
group by unidade.id_categoria;

-- 4. Quais são as unidades que têm faturas pendentes de pagamento?
select unidade.id_unidade, fatura.status_fatura from fatura
left join unidade on unidade.id_unidade like fatura.id_unidade
where fatura.status_fatura like 'Pendente';

-- 5. Quais são as unidades que têm faturas vencidas?
select id_fatura , data_vencimento , status_fatura from fatura where
curdate() > data_vencimento AND status_fatura <> 'Pago';
-- data_pagamento > data_vencimento;

