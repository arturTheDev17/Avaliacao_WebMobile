-- 1. Atualizar o valor do aluguel de uma unidade específica.
update unidade set valor_aluguel = 1000 where unidade_id = 3;
-- 2. Alterar alguma informação sobre o proprietário de uma unidade, como o CPF ou o número de telefone.

update proprietario 
inner join unidade on proprietario.id_proprietario = unidade.id_proprietario 
set cpf = '12345678987' 
where unidade.id_unidade = 2;

-- 3. Atualizar a categoria de uma unidade para refletir mudanças em sua atividade comercial.

update unidade set id_categoria = 2 where id_categoria = 1;

-- 4. Faça mudanças nos horários de funcionamento de uma unidade no sistema.

update horario_funcionamento set horario_abertura = '12:00:00' , horario_fechamento = '18:00:00' where dia_semana = 'domingo' and id_horario > 0;

-- 5. Atualize faturas vencidas que precisam ser marcadas como pagas ou tiveram sua data de vencimento prorrogada.

update fatura set data_pagamento = current_date() , status_fatura = 'Pago' where id_fatura = 2;

-- 6. Mude o status de alguma unidade de funcionamento, passando de aberta para fechada, ou vice-versa.

alter table unidade add column status_unidade varchar(50) not null;
update unidade set status_unidade = if( id_unidade % 2 = 0 , 'fora de serviço' , 'em funcionamento' ) 
where id_unidade > 0;

-- 7. Atualize as informações de contato de um proprietário, como endereço de e-mail ou número de telefone.

alter table proprietario add column email varchar(128);
update proprietario
set email = CONCAT(LOWER(replace(nome, ' ', '')), '@gmail.com')
where id_proprietario > 0;
 
-- 8. Foi identificado algum erro nos detalhes da unidade, como o número do andar ou a localização, que precisa ser corrigido.

update unidade set numero_andar = 1 where numero_andar = 2 and metros_quadrados > 100 and id_unidade > 0;

-- 9. Alguma unidade mudou de marca ou franquia e precisa ser atualizada para refletir essa alteração.

update unidade set id_proprietario = 2 , id_categoria = 4 where id_proprietario = 3 and id_unidade = 3;

-- 10. Houve mudanças nos termos do contrato de aluguel de uma unidade que precisa ser atualizada nos registros do sistema.

update unidade set valor_aluguel = if ( valor_aluguel * 1.1 < 5000 , valor_aluguel * 1.1 , valor_aluguel ) where id_unidade = 16;