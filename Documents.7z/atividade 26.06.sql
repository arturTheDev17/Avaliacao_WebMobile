create database hospital;
use hospital;

-- tabelas
create table medico (
    crm int auto_increment not null primary key,
    nome_med varchar(150) not null,
    ender_med varchar(150) not null,
    cidade_med varchar(50) not null,
    uf_med char(2) not null
);

create table paciente (
    cod_pac int auto_increment not null primary key,
    nome_pac varchar(150) not null,
    ender_pac varchar(150) not null,
    cidade_pac varchar(100) not null,
    uf_pac char(2) not null,
    fone_pac char(10) not null
);

create table consulta (
    cod_con int auto_increment not null primary key,
    data_consulta date not null,
    hora time not null,
    crm int not null,
    cod_pac int not null,
    historico varchar(200),
    foreign key (crm) references medico(crm),
    foreign key (cod_pac) references paciente(cod_pac)
);

create table espmedico (
    crm int not null,
    codesp int not null,
    foreign key (crm) references medico(crm),
    foreign key (codesp) references especialidade(codesp)
);

create table fonemedico (
    crm int not null,
    fone varchar(20) not null,
    foreign key (crm) references medico(crm)
);

create table especialidade (
    codesp int auto_increment not null primary key,
    especialidade varchar(100) not null
);

-- inserts
insert into medico (crm, nome_med, ender_med, cidade_med, uf_med) values
(1001, 'maria das dores', 'rua das acacias', 'chapeco', 'sc'),
(1002, 'joao da silva', 'rua dos coqueiros', 'xaxim', 'sc'),
(1003, 'ana paula padrao', 'rua sao paulo', 'chapeco', 'sc'),
(1004, 'flavio bohr', 'rua sao joao', 'xanxere', 'sc');

insert into paciente (cod_pac, nome_pac, ender_pac, cidade_pac, uf_pac, fone_pac) values
(1, 'maria ana soares', 'av. getulio vargas', 'chapeco', 'sc', '3236988'),
(2, 'carlos araujo', 'av. fernando machado', 'chapeco', 'sc', '3234888'),
(3, 'pedro pereira', 'rua do comercio', 'xaxim', 'sc', '3227020');

insert into consulta (data_consulta, hora, crm, cod_pac, historico) values
('2000-07-05', '14:00:00', 1001, 1, 'fratura de omoplata'),
('2000-08-30', '10:00:00', 1001, 1, 'refluxo'),
('2000-11-10', '8:00:00', 1002, 3, 'pe direito quebrado'),
('2000-11-27', '8:00:00', 1001, 2, 'apresenta dores de cabeca');

insert into espmedico (crm, codesp) values
(1001, 100),
(1001, 101),
(1002, 101),
(1003, 103);

insert into fonemedico (crm, fone) values
(1001, '998576455'),
(1001, '99987400'),
(1002, '3238789'),
(1003, '3221470'),
(1004, '3240857');

insert into especialidade (codesp, especialidade) values
(100, 'otorrinolaringologista'),
(101, 'ortopedista'),
(102, 'pediatra'),
(103, 'gastroenterologista'),
(104, 'cirurgiao'),
(105, 'clinico geral');

select * from medico;
select * from paciente;
select * from especialidade;
select * from consulta;
select * from espmedico;
select * from fonemedico;

-- atividades
-- a. Mostrar o nome, endereço e telefone de cada paciente.
select nome_pac , ender_pac , cidade_pac , uf_pac , fone_pac 
from paciente;

-- b. Mostrar o nome e telefones de cada médico.  
select m.nome_med , t.fone from medico m
inner join fonemedico t on t.crm = m.crm;

-- c. Mostrar o nome, endereço e telefones de cada médico.  
select m.nome_med , m.ender_med , m.cidade_med , m.uf_med , t.fone 
from medico m
inner join fonemedico t on t.crm = m.crm;

-- d. Mostrar o nome de cada paciente, a data e hora de suas consultas.

select p.nome_pac , c.data_consulta , c.hora from paciente p 
inner join consulta c on c.cod_pac = p.cod_pac;

-- e. Mostrar o nome dos médicos e suas especialidades. 

select m.nome_med , e.especialidade from medico m
inner join espmedico s on s.crm = m.crm
inner join especialidade e on s.codesp = e.codesp;